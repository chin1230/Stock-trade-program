
# DESIGN-README


### Changes and Improvements ###
================================

1. Portfolio / PortfolioManager Class Enhancements:
    - ** Adding/Removing stocks **:
        - Fix bugs in adding/removing stocks and updating the changes in the XML portfolio file. 

    - ** New design **:
        - Portfolio now stores its stocks as a HashMap containing the stock ticker and its quantity.
        - Added a Transaction class to store details about the buying/selling activities of a stock.
        - Refactor all methods in Portfolio and PortfolioManager to accommodate this new design with the new HashMap and the Transaction class. 

    - ** Justification **:
        - Store information about transactions separately to avoid the Portfolio class handling too much information and responsibilites. 

================================

2. Transaction Class Creation:
    - ** Details **:
        - Each Transaction class stores information about the type of transaction (buy/sell), date of the activity, quantity of stocks being transacted, the name of the stock. 
        - Added getters/setters for each field. 
        - Added getters/setters for each field. 
    - ** Justification **:
        - Store information about transactions separately to avoid the Portfolio class handling too much information and responsibilites. 

================================

3. PortfolioXMLHandler Class Improvement:
    - ** Save / Update a portfolio after adding/removing stocks **:
        - Instead of the old design choice of editing the portfolio XML file, the program now saves a new portfolio with the same name, original stocks with added / removed stocks reflected inside. 

    - ** Justification **:
        - To avoid modification problems and bugs that the old design had. 

================================

4. GUI Integration:
    - ** Addition of GuiView Class **:
        - 'GuiView.java': This class was introduced to provide a graphical user interface (GUI) for the portfolio management application. 
    - ** Justification **:
        - The addition of GuiView allows users to interact with the application through a more intuitive and user-friendly interface, enhancing the overall user experience. It displays stock information, portfolio performance, and provides input forms for user actions. 


    - ** Addition of GuiController Class **:
        - 'GuiController.java': This class was added to handle the interaction between the GUI and the backend logic of the application.
    - ** Justification **:
        - The GuiController acts as a mediator between the user interface (GuiView) and the application logic. It processes user inputs from the GUI, triggers the corresponding actions in the backend, and updates the GUI with the results. This separation of concerns improves the maintainability and scalability of the code. 

================================

