
Project Overview
================
This project is a portfolio management application that allows users to manage their stock investments. It provides functionality for adding and managing stock transactions, viewing portfolio performance, and handling different types of portfolios.

Features
========

1. Account Management
---------------------
- **Account.java**: Manages user account details including login and personal information.
- **Complete and Functional**: Users can create, update, and manage their accounts within the application.

2. Portfolio Management
-----------------------
- **Portfolio.java**: Handles the creation and management of portfolios.
- **PortfolioManager.java**: Manages multiple portfolios and provides functionality for adding and removing portfolios.
- **PortfolioTypes.java**: Defines different types of portfolios supported by the application.
- **Complete and Functional**: Users can create various types of portfolios, add stocks to them, and view their performance.

3. Stock Transactions
---------------------
- **Transaction.java**: Manages individual stock transactions including buying and selling stocks.
- **Complete and Functional**: Users can record transactions and manage their stock investments.

4. Stock Data Handling
----------------------
- **StockData.java**: Fetches and processes stock market data.
- **Complete and Functional**: The application can fetch real-time stock data and update portfolio values accordingly.

5. Graphical User Interface (GUI)
---------------------------------
- **GuiController.java**: Controls the interaction between the user interface and the backend logic.
- **GuiView.java**: Provides the graphical user interface for the application.
- **StockView.java**: Displays stock information to the user.
- **Complete and Functional**: The application has a user-friendly interface for managing accounts, portfolios, and transactions.

6. Application Logic
--------------------
- **PortfolioApp.java**: Main application class that initializes and runs the portfolio management system.
- **StockProgram.java**: Main program class that integrates all components and starts the application.
- **Complete and Functional**: The application initializes correctly and all integrated components work seamlessly.

7. XML Handling
---------------
- **PortfolioXMLHandler.java**: Handles the import and export of portfolio data in XML format.
- **Complete and Functional**: Users can import and export their portfolio data for backup and restoration purposes.

Additional Resources
====================

- **Test Files**: Located in the root directory, providing various XML files (`test2.xml`, `testAddStock.xml`, `bug35.xml`) to test different functionalities of the application.
- **Data Files**: Contains CSV files (`AAPL.csv`, `GOOG.csv`, `IBM.csv`, `MCD.csv`, `META.csv`, `NFLX.csv`, `NVDA.csv`) for stock data used by the application.

Directory Structure
===================

- **src/stock**: Contains all the Java source files for the application.
- **META-INF**: Contains metadata files for the application.
- **test**: Contains test cases and related files.

How to Run
==========

1. Compile the Java source files in the `src/stock` directory.
2. Run the main application class `PortfolioApp.java` or `StockProgram.java`.
3. Use the provided GUI to manage your stock portfolios and transactions.

Dependencies
============

- Java Development Kit (JDK)
- Any additional libraries specified in the project configuration files.
