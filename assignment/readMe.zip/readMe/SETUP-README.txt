Setup Instructions
 
- Download the JAR File:
- Place the JAR file in your desired directory.

===============
Required Files:

Ensure the following files are in the same directory as the JAR file:
- config.properties (contains the AlphaVantage API key)
- Any other configuration files required by your application.

Running the Program:
Open a terminal/command prompt in the directory containing the JAR file and run the following command:
For the GUI:
java -jar HW4.jar 

For the text-based interface:
java -jar HW4.jar -text


Thank you for using our program! 
*******************************