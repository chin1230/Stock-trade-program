package stock;

/**
 * public interface representing where info can be store.
 * this can be used more in the future if there is more API other than
 * the stock API. 
 */
public interface IData {
}
